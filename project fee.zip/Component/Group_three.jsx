import React from 'react'

function Group_three() {
  return (
<div className="group-3">
    <div className="l-constrained-4 match-height group">
      <div className="column-1">
        <div className='flex-visible'>
        <div className="ellipse" />
        <p className="title-4">New tastes</p>
        </div>
        <p className="body-text-2">
          Lorem ipsum dolor sit amet, consecte
          <br />
          sectetur adipisicing elit, tation omne
          <br />
          ullamco laboris nisi ut aliqolore.
        </p>
      </div>
      <div className="column-1">
        <div className='flex-visible'>
        <div className="ellipse" />
        {/* <div className="ellipse" /> */}
        <p className="title-4">New Spices</p>
        </div>
        <p className="body-text-2">
          Lorem ipsum dolor sit amet, consecte
          <br />
          sectetur adipisicing elit, tation omne
          <br />
          ullamco laboris nisi ut aliqolore.
        </p>
      </div>
      <div className="column-1">
        <div className='flex-visible'>
        <div className="ellipse" />
        {/* <div className="ellipse" /> */}
        {/* <div className="ellipse" /> */}

        <p className="title-4">New Dishes</p>
        </div>
        <p className="body-text-2">
          Lorem ipsum dolor sit amet, consecte
          <br />
          sectetur adipisicing elit, tation omne
          <br />
          ullamco laboris nisi ut aliqolore.
        </p>
      </div>
    </div>
  </div>  )
}

export default Group_three