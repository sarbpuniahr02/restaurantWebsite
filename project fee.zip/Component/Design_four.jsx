import React from 'react'
import place_your_design_here_do_4 from '../images/place_your_design_here_do_4.png';
import place_your_design_here_do_3 from '../images/place_your_design_here_do_3.jpg';
import place_your_design_here_do_2 from '../images/place_your_design_here_do_2.jpg';
function Design_four() {
  return (
<div className="design-4">
    <div className="l-constrained-2" id='events'>
      <div className="main-title-2">
        <p className="title-34">Discoverr</p>
        <p className="title-35">our new menu</p>
      </div>
      <div className="row match-height group">
        <div className="square-1">
          <img
            className="place-your-design-here-double-click-to-edit-10"
            src={place_your_design_here_do_4}
            alt=""
            width={339}
            height={301}
          />
          <div className="col-3">
            <p className="date">Food / 16th March, 2019</p>
            <p className="title-36">Lorem ipsum dolor sit</p>
            <p className="body-text-19">
              Lorem ipsum dolor sit amet,
              <br />
              consectetur adipisicing elit, sed
            </p>
            <p className="text-7">READ MORE</p>
            <div className="rectangle-6" />
          </div>
        </div>
        <div className="square-2 square-1">
          <img
            className="place-your-design-here-double-click-to-edit-11"
            src={place_your_design_here_do_3}
            alt=""
            width={339}
            height={301}
          />
          <div className="col-2 col-3">
            <p className="date-2">Spices / 16th March, 2019</p>
            <p className="title-37">Lorem ipsum dolor sit</p>
            <p className="body-text-20">
              Lorem ipsum dolor sit amet lipum
              <br />
              consectetur adipisicing elit, sed
            </p>
            <p className="text-8">READ MORE</p>
            <div className="rectangle-7" />
          </div>
        </div>
        <div className="square-3 square-1">
          <img
            className="place-your-design-here-double-click-to-edit-12"
            src={place_your_design_here_do_2}
            alt=""
            width={339}
            height={301}
          />
          <div className="col col-3">
            <p className="date-3">Chicken Curry / 16th March, 2019</p>
            <p className="title-38">Lorem ipsum dolor sit</p>
            <p className="body-text-21">
              Lorem ipsum dolor sit amet lipum
              <br />
              consectetur adipisicing elit, sed
            </p>
            <p className="text-9">READ MORE</p>
            <div className="rectangle-8" />
          </div>
        </div>
      </div>
    </div>
  </div>  )
}

export default Design_four