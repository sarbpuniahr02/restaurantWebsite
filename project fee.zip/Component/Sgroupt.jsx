import React from 'react'
import place_your_design_here_do_15 from '../images/place_your_design_here_do_15.png';

function Sgroupt() {
  return (
    <div className="group-2 group">
    <div className="text-2">
      <p className="title-3">Indian traditional flavours</p>
      <p className="body-text">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris
      </p>
    </div>
    <img
      className="place-your-design-here-double-click-to-edit image1"
      src={place_your_design_here_do_15}
      alt=""
      width={527}
      height={354}
    />
  </div>
  )
}

export default Sgroupt