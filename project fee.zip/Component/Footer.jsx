import React from 'react'

function Footer() {
  return (
    <div className="group-11">
    <div className="l-constrained group">
      <div className="col-5">
        <p className="title-39">about</p>
        <p className="body-text-23">
          Lorem ipsum dolor sit amet, consec tetur adipisicing elit, sed do
          eiusmod tempor incididunt ultimam quantum
        </p>
      </div>
      <div className="col-16">
        <p className="about-3">about</p>
        <p className="team-3">Team</p>
        <p className="text-13">Join us</p>
        <p className="ethic-3">Ethic</p>
        <p className="goals-3">Goals</p>
      </div>
      <div className="col-15">
        <p className="about-2">about</p>
        <p className="team-2">Team</p>
        <p className="text-12">Join us</p>
        <p className="ethic-2">Ethic</p>
        <p className="goals-2">Goals</p>
      </div>
      <div className="col-14">
        <p className="about">about</p>
        <p className="team">Team</p>
        <p className="text-11">Join us</p>
        <p className="ethic">Ethic</p>
        <p className="goals">Goals</p>
      </div>
    </div>
  </div>  )
}

export default Footer