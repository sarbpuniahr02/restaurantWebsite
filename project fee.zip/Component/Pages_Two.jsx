import React from 'react'

function Pages_Two() {
  return (
    <div style={{color:"#fff", fontSize:"30px", textAlign:"center", padding:"100px"}}> This is our Pages Two of routing</div>
  )
}

export default Pages_Two